#!/usr/bin/env node
import fs from "node:fs/promises";
import path from "node:path";
import { spawn } from "node:child_process";

const cliArgs = process.argv.slice(2);
const dryRun = process.env.DRY_RUN === "1" || cliArgs.includes("--dry-run");
const outputDirArg = cliArgs.find(x => x.startsWith("--output-dir="))?.slice("--output-dir=".length);
const batchIdArg = cliArgs.find(x => x.startsWith("--batch-id="))?.slice("--batch-id=".length);
const pairArgs = cliArgs.filter(x => x !== "--dry-run" && !x.startsWith("--output-dir=") && !x.startsWith("--batch-id="));
const pair = pairArgs.join(" ").trim() || "Egypt vs Algeria";
const outputDir = outputDirArg ? path.resolve(outputDirArg) : null;

const run = (cmd, args, opts={}) => new Promise((resolve,reject)=>{
  const p = spawn(cmd,args,{stdio:"inherit",shell:process.platform==="win32",...opts});
  p.on("close", code => code===0 ? resolve() : reject(new Error(`${cmd} exited ${code}`)));
});

async function main() {
  console.log(`\n=== MILITARY MAP PIPELINE ===`);
  console.log(`Matchup: ${pair}`);
  console.log(`Mode: ${dryRun ? "DRY RUN" : "LIVE"}\n`);

  // Step 1: research + structured matchup
  const researchArgs = ["scripts/research-matchup.mjs", pair];
  if (dryRun) researchArgs.push("--dry-run");
  await run("node", researchArgs);

  const matchupPath = path.join("data", "current-matchup.json");
  const matchup = JSON.parse(await fs.readFile(matchupPath, "utf8"));

  if (dryRun) {
    console.log("\nDRY RUN complete. Research call, ElevenLabs and Remotion were skipped.");
    return;
  }

  // Step 2: deterministic validation/scoring
  await run("node", ["scripts/validate-matchup.mjs", matchupPath]);

  // Step 3: narration + timestamps + captions
  await run("node", ["scripts/generate-audio.mjs", matchupPath]);
  await run("node", ["scripts/make-captions.mjs"]);
  await run("node", ["scripts/build-episode-spec.mjs", matchupPath]);
  await run("node", ["scripts/prepare-render-data.mjs", matchupPath]);

  // Step 4: production QC
  await run("node", ["scripts/qc-visual.mjs", matchupPath]);

  // Step 5: render
  await run("npx", ["remotion", "render", "MilitaryMatchup", "output/final.mp4", "--props", matchupPath]);

  if (outputDir) {
    await fs.mkdir(outputDir,{recursive:true});
    const files = ["output/final.mp4","data/current-matchup.json","data/matchup.json","data/episode-spec.json","audio/captions.json","public/audio/narration.mp3","public/audio/narration-alignment.json"];
    for (const rel of files) {
      try {
        const src=path.resolve(rel);
        const dest=path.join(outputDir,path.basename(rel));
        await fs.copyFile(src,dest);
      } catch {}
    }
    await fs.writeFile(path.join(outputDir,'batch-meta.json'),JSON.stringify({batch_id:batchIdArg||null,matchup:pair,duration_seconds:90,created_at:new Date().toISOString()},null,2));
    console.log(`\n=== COMPLETE ===\n${path.join(outputDir,'final.mp4')}`);
  } else {
    console.log("\n=== COMPLETE ===");
    console.log("output/final.mp4");
  }
}
main().catch(e=>{ console.error("\nPIPELINE FAILED:", e.message); process.exit(1); });
