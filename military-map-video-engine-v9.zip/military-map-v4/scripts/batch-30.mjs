#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';

const root = new URL('..', import.meta.url).pathname;
const batch = JSON.parse(fs.readFileSync(new URL('../data/batch-30.json', import.meta.url), 'utf8'));
const argv = process.argv.slice(2);
const getNum = (name, fallback) => Number(argv.find(x => x.startsWith(`--${name}=`))?.split('=')[1] || fallback);
const limit = getNum('limit', batch.matchups.length);
const start = getNum('start', 1);
const dry = argv.includes('--dry-run');
const stopOnError = argv.includes('--stop-on-error');
const outRoot = path.join(root, 'output', 'batch-30');
fs.mkdirSync(outRoot, {recursive:true});
const selected = batch.matchups.slice(start-1, start-1+limit);
const manifestPath = path.join(outRoot,'manifest.json');
const manifest = fs.existsSync(manifestPath) ? JSON.parse(fs.readFileSync(manifestPath,'utf8')) : {batch_version:'9.0',generated_at:new Date().toISOString(),total:batch.matchups.length,results:[]};
const prior = new Map(manifest.results.map(x=>[x.id,x]));
for (const m of selected) {
  const slug = `${m.id}-${m.country1.toLowerCase().replace(/[^a-z0-9]+/g,'-')}-vs-${m.country2.toLowerCase().replace(/[^a-z0-9]+/g,'-')}`;
  const outDir = path.join(outRoot, slug);
  console.log(`\n=== ${m.id}: ${m.country1} vs ${m.country2} ===`);
  if (dry) { prior.set(m.id,{id:m.id,status:'planned',slug}); continue; }
  const r = spawnSync('node',['scripts/oneclick.mjs',`${m.country1} vs ${m.country2}`,`--batch-id=${m.id}`,`--output-dir=${outDir}`],{cwd:root,stdio:'inherit',env:process.env});
  const result={id:m.id,status:r.status===0?'completed':'failed',slug};
  prior.set(m.id,result);
  fs.writeFileSync(manifestPath,JSON.stringify({...manifest,results:[...prior.values()]},null,2));
  if (r.status!==0 && stopOnError) break;
}
const final={batch_version:'9.0',generated_at:manifest.generated_at,total:batch.matchups.length,results:[...prior.values()]};
fs.writeFileSync(manifestPath,JSON.stringify(final,null,2));
console.log(`\nBatch 30 complete: ${final.results.filter(x=>x.status==='completed').length}/${batch.matchups.length} completed.`);
