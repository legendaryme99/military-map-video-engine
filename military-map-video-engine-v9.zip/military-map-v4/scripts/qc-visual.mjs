#!/usr/bin/env node
import fs from 'node:fs/promises';
const d=JSON.parse(await fs.readFile(process.argv[2]||'data/current-matchup.json','utf8'));
const errors=[],warnings=[];
if(!d.matchup?.country1||!d.matchup?.country2) errors.push('Missing country pair');
if(!d.stats?.length) errors.push('No researched statistics');
if(!d.sources?.length) warnings.push('No sources array populated');
for(const s of d.stats||[]){if(s.value===undefined||s.value===null) errors.push(`Missing value: ${s.label}`);if(!s.source_url) errors.push(`Missing source URL: ${s.label}`);if(!s.year) errors.push(`Missing source year: ${s.label}`);}
const scores=d.scores||{};if(typeof scores.country1!=='number'||typeof scores.country2!=='number')errors.push('Invalid deterministic scores');
const out={pass:errors.length===0,errors,warnings,checks:{statsPresent:!!d.stats?.length,sourceCompleteness:!errors.some(e=>e.includes('source')),scoresPresent:typeof scores.country1==='number'&&typeof scores.country2==='number'}};
await fs.mkdir('output',{recursive:true});await fs.writeFile('output/qc-report.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));if(errors.length)process.exit(1);
