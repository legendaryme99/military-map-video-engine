#!/usr/bin/env node
import fs from 'node:fs/promises';
const alignment=JSON.parse(await fs.readFile('public/audio/narration-alignment.json','utf8'));
const chars=alignment.characters||[], starts=alignment.character_start_times_seconds||[], ends=alignment.character_end_times_seconds||[];
const captions=[]; let text='', start=0, end=0;
for(let i=0;i<chars.length;i++){
  if(!text) start=starts[i]*1000;
  text+=chars[i]; end=ends[i]*1000;
  if(/[.!?]\s*$/.test(text)||(text.length>72&&/\s/.test(chars[i]))){captions.push({text:text.trim(),startMs:start,endMs:end,timestampMs:(start+end)/2,confidence:null});text='';}
}
if(text.trim()) captions.push({text:text.trim(),startMs:start,endMs:end,timestampMs:(start+end)/2,confidence:null});
await fs.writeFile('data/captions.json',JSON.stringify(captions,null,2));
console.log(`CAPTIONS PASS: ${captions.length} captions`);
