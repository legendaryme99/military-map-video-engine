#!/usr/bin/env node
import fs from 'node:fs/promises';
import process from 'node:process';

async function loadEnv(){try{const t=await fs.readFile('.env','utf8');for(const line of t.split(/\r?\n/)){const m=line.match(/^\s*([A-Z0-9_]+)=(.*)\s*$/);if(m&&!process.env[m[1]])process.env[m[1]]=m[2].replace(/^['"]|['"]$/g,'')}}catch{}}
await loadEnv();
const file=process.argv[2]||'data/current-matchup.json';
const d=JSON.parse(await fs.readFile(file,'utf8'));
const key=process.env.ELEVENLABS_API_KEY;
const voice=process.env.ELEVENLABS_VOICE_ID;
const model=process.env.ELEVENLABS_MODEL_ID||'eleven_multilingual_v2';
if(!key) throw new Error('ELEVENLABS_API_KEY is required.');
if(!voice) throw new Error('ELEVENLABS_VOICE_ID is required.');
const text=d.narration;
if(!text) throw new Error('No narration in matchup JSON.');
const url=`https://api.elevenlabs.io/v1/text-to-speech/${voice}/with-timestamps`;
const r=await fetch(url,{method:'POST',headers:{'xi-api-key':key,'Content-Type':'application/json'},body:JSON.stringify({text,model_id:model,output_format:'mp3_44100_128'})});
if(!r.ok) throw new Error(`ElevenLabs ${r.status}: ${(await r.text()).slice(0,600)}`);
const out=await r.json();
await fs.mkdir('public/audio',{recursive:true});
await fs.writeFile('public/audio/narration.mp3',Buffer.from(out.audio_base64,'base64'));
await fs.writeFile('public/audio/narration-alignment.json',JSON.stringify(out.alignment??out.normalized_alignment,null,2));
console.log('AUDIO PASS: public/audio/narration.mp3');
