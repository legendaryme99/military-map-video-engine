import fs from 'node:fs';
import { spawnSync } from 'node:child_process';

const root = new URL('..', import.meta.url).pathname;
const batch = JSON.parse(fs.readFileSync(new URL('../data/batch-100.json', import.meta.url), 'utf8'));
const args = new Set(process.argv.slice(2));
const limit = Number([...args].find(x => /^--limit=/.test(x))?.split('=')[1] || 100);
const start = Number([...args].find(x => /^--start=/.test(x))?.split('=')[1] || 1);
const dry = args.has('--dry-run');
const stopOnError = args.has('--stop-on-error');
const selected = batch.matchups.slice(start - 1, start - 1 + limit);
fs.mkdirSync(new URL('../output/batch-100/', import.meta.url), {recursive:true});
const manifest = {batch_version:'8.0', generated_at:new Date().toISOString(), total:selected.length, results:[]};
for (const m of selected) {
  const slug = `${m.id}-${m.country1.toLowerCase().replace(/[^a-z0-9]+/g,'-')}-vs-${m.country2.toLowerCase().replace(/[^a-z0-9]+/g,'-')}`;
  console.log(`\n=== ${m.id}: ${m.country1} vs ${m.country2} ===`);
  if (dry) { manifest.results.push({id:m.id,status:'planned',slug}); continue; }
  const r = spawnSync('node',[new URL('./oneclick.mjs',import.meta.url).pathname,`${m.country1} vs ${m.country2}`,'--batch-id',m.id,'--output-dir',`output/batch-100/${slug}`],{cwd:root,stdio:'inherit',env:process.env});
  const status = r.status===0?'completed':'failed'; manifest.results.push({id:m.id,status,slug});
  if (r.status!==0 && stopOnError) break;
}
fs.writeFileSync(new URL('../output/batch-100/manifest.json',import.meta.url),JSON.stringify(manifest,null,2));
console.log(`\nBatch complete: ${manifest.results.filter(x=>x.status==='completed').length}/${selected.length} completed.`);
