import React from 'react';
import {registerRoot} from 'remotion';
import {Composition} from 'remotion';
import {MilitaryMatchup} from './MilitaryMatchup';
import matchup from './data/matchup.json';
export const RemotionRoot=()=> <Composition id="MilitaryMatchup" component={MilitaryMatchup} durationInFrames={2700} fps={30} width={1080} height={1920} defaultProps={{data:matchup}}/>;
registerRoot(RemotionRoot);
