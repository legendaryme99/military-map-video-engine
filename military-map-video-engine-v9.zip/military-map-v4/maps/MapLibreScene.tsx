import React, {useEffect, useRef} from 'react';
import {AbsoluteFill, delayRender, continueRender, useCurrentFrame, interpolate} from 'remotion';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import {northAfrica} from './geo';

type Props = {mode?: 'intro'|'regional'|'mediterranean'; countries?: string[]};

export const MapLibreScene: React.FC<Props> = ({mode='regional', countries=[]}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const [handle] = React.useState(() => delayRender('Loading MapLibre map'));
  const frame = useCurrentFrame();

  useEffect(() => {
    if (!containerRef.current) return;
    const map = new maplibregl.Map({
      container: containerRef.current,
      style: 'https://demotiles.maplibre.org/style.json',
      center: [15, 29], zoom: 3.2, interactive: false,
      attributionControl: false, fadeDuration: 0
    });
    mapRef.current = map;
    map.on('load', () => {
      map.addSource('matchup-countries', {type: 'geojson', data: northAfrica});
      map.addLayer({id:'country-fill',type:'fill',source:'matchup-countries',paint:{'fill-color':['match',['get','iso_a3'],'EGY','#e7c84b','DZA','#39a7ff','#222'],'fill-opacity':0.46}});
      map.addLayer({id:'country-outline',type:'line',source:'matchup-countries',paint:{'line-color':'#ffffff','line-width':2.2,'line-opacity':0.92}});
      continueRender(handle);
    });
    map.on('error', () => continueRender(handle));
    return () => { map.remove(); mapRef.current=null; };
  }, [handle]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !map.isStyleLoaded()) return;
    const t = Math.min(1, Math.max(0, frame / 150));
    if (mode === 'intro') map.jumpTo({center:[18,27],zoom:interpolate(t,[0,1],[2.0,4.0]),bearing:interpolate(t,[0,1],[0,3]),pitch:12});
    else if (mode === 'mediterranean') map.jumpTo({center:[12,33],zoom:interpolate(t,[0,1],[3.2,4.5]),bearing:0,pitch:8});
    else map.jumpTo({center:[15,29],zoom:3.6,bearing:0,pitch:0});
  }, [frame, mode]);

  return <AbsoluteFill style={{background:'#071018'}}><div ref={containerRef} style={{width:'100%',height:'100%',filter:'saturate(.65) contrast(1.2) brightness(.68)'}}/><div style={{position:'absolute',inset:0,background:'radial-gradient(circle at 50% 45%, transparent 22%, rgba(0,0,0,.68) 100%)',pointerEvents:'none'}}/></AbsoluteFill>;
};
