#!/usr/bin/env node
import fs from "node:fs/promises";
const file = process.argv[2] || "data/current-matchup.json";
const d = JSON.parse(await fs.readFile(file,"utf8"));
const errors=[];
if (!d.matchup?.country1 || !d.matchup?.country2) errors.push("Missing countries");
if (!Array.isArray(d.categories) || d.categories.length !== 9) errors.push("Expected 9 weighted categories");
const total = (d.categories||[]).reduce((s,c)=>s+Number(c.weight||0),0);
if (total !== 100) errors.push(`Category weights total ${total}, expected 100`);
for (const s of d.stats||[]) {
  if (!s.source_name && !s.source) errors.push(`Stat missing source: ${s.label||"unknown"}`);
  if (!s.year) errors.push(`Stat missing year: ${s.label||"unknown"}`);
  if (!s.source_url) errors.push(`Stat missing source URL: ${s.label||"unknown"}`);
}
const cs=d.scores?.category_scores||[];
if (cs.length !== 9) errors.push(`Expected 9 category scores, got ${cs.length}`);
for (const c of d.categories||[]) if (!cs.find(x=>x.id===c.id)) errors.push(`Missing score for category: ${c.id}`);
for (const c of cs) {
  for (const k of ["country1_score","country2_score"]) if (!Number.isFinite(Number(c[k])) || Number(c[k])<0 || Number(c[k])>100) errors.push(`Invalid ${k} for ${c.id}`);
}
if (!Number.isFinite(Number(d.scores?.country1)) || !Number.isFinite(Number(d.scores?.country2))) errors.push("Missing final deterministic scores");
if (!d.verdict || !d.narration) errors.push("Missing verdict/narration");
if (errors.length) { console.error("QC FAIL:\n"+errors.join("\n")); process.exit(1); }
console.log(`QC PASS: ${d.matchup.country1} vs ${d.matchup.country2}; 9 categories; weights=100; sources=${d.sources?.length||0}; stats=${d.stats?.length||0}`);
