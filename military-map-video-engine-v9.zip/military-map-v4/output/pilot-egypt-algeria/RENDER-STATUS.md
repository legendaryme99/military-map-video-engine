# Egypt vs Algeria — Pilot Render Status

Status: RENDER-READY / NOT RENDERED IN THIS RUNTIME

The pilot research packet, deterministic score model, render data, and 90-second episode specification have passed local validation.

## Episode
- 90 seconds
- 30 fps
- 9:16 vertical
- 9 scenes
- Hypothetical conventional comparison
- Model estimate, not a prediction

## Model result
- Egypt: 52.9
- Algeria: 47.1
- Confidence: low-moderate

## Why there is no MP4 here
The runtime could not access the npm registry or ElevenLabs API, so dependencies and narration could not be downloaded/generated. No fake render is included.

## When run on a connected machine
1. `npm install`
2. Ensure `.env` contains the Gemini/ElevenLabs credentials.
3. `node scripts/validate-matchup.mjs data/current-matchup.json`
4. `node scripts/build-episode-spec.mjs data/current-matchup.json`
5. `node scripts/prepare-render-data.mjs data/current-matchup.json`
6. `node scripts/generate-audio.mjs data/current-matchup.json`
7. `node scripts/make-captions.mjs`
8. `npx remotion render MilitaryMatchup output/final.mp4 --props data/matchup.json`
