#!/usr/bin/env node
import fs from 'node:fs/promises';
const d=JSON.parse(await fs.readFile(process.argv[2]||'data/current-matchup.json','utf8'));
const a=d.matchup.country1,b=d.matchup.country2;
const stat=(label, fallbackLabel=label)=>{
  const x=(d.stats||[]).find(s=>s.label?.toLowerCase().includes(label.toLowerCase()));
  return x || {country:a,label:fallbackLabel,value:0,unit:'estimate',year:d.matchup.year,source_name:'Research',source_url:''};
};
const by=(label,country)=> (d.stats||[]).find(s=>s.country===country&&s.label?.toLowerCase().includes(label.toLowerCase()));
const pair=(label,unit='systems')=>({name:label,a:by(label,a)?.value??0,b:by(label,b)?.value??0,unit,advantage:(by(label,a)?.value??0)>=(by(label,b)?.value??0)?a:b,source:(by(label,a)?.source_name||by(label,b)?.source_name||'Research')});
const spend=(d.stats||[]).find(s=>/military expenditure|military spending|defence spending|defense spending/i.test(s.label));
const out={countryA:a,countryB:b,year:d.matchup.year,scenario:d.matchup.scenario,sources:d.sources,categories:[pair('active personnel','active personnel'),pair('total aircraft','total aircraft'),pair('fighters','fighter aircraft'),pair('tanks','tanks'),pair('self-propelled artillery','systems'),pair('naval assets','assets')],spending:spend?{country:spend.country,year:spend.year,amountBillions:Number(spend.value),currency:'USD',source:spend.source_name}:{country:a,year:d.matchup.year,amountBillions:0,currency:'USD',source:'Research'},model:{weights:Object.fromEntries(d.categories.map(c=>[c.id,c.weight])),scores:{[a]:d.scores.country1,[b]:d.scores.country2},confidence:d.scores.confidence,note:'Illustrative channel model using stated weights; not a scientific prediction.'},result:{country:d.scores.winner?.startsWith(a)?a:b,label:'MODEL ESTIMATE: BROADER CONVENTIONAL ADVANTAGE'},narration:d.narration};
await fs.writeFile('data/matchup.json',JSON.stringify(out,null,2));
console.log('RENDER DATA PASS');
