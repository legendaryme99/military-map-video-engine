#!/usr/bin/env node
import fs from "node:fs/promises";
import process from "node:process";

function loadDotEnv(path = ".env") {
  return fs.readFile(path, "utf8").then(txt => {
    for (const raw of txt.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line || line.startsWith("#") || !line.includes("=")) continue;
      const i = line.indexOf("=");
      const k = line.slice(0, i).trim();
      let v = line.slice(i + 1).trim();
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
      if (k && !process.env[k]) process.env[k] = v;
    }
  }).catch(() => {});
}
await loadDotEnv();

const args = process.argv.slice(2);
const dryRun = args.includes("--dry-run");
const input = args.filter(x => x !== "--dry-run").join(" ").trim();
if (!input) throw new Error('Usage: node scripts/research-matchup.mjs "Egypt vs Algeria" [--dry-run]');

const [rawA, rawB] = input.split(/\s+vs\.?\s+/i);
if (!rawA || !rawB) throw new Error("Use the format: Country A vs Country B");
const a = rawA.trim();
const b = rawB.trim();
const year = Number(process.env.MATCHUP_YEAR || new Date().getUTCFullYear());

const categories = [
  {id:"air", label:"Air power", weight:20},
  {id:"ground", label:"Ground power", weight:15},
  {id:"naval", label:"Naval power", weight:10},
  {id:"air_defense", label:"Air defense", weight:10},
  {id:"logistics", label:"Logistics", weight:15},
  {id:"geography", label:"Geography", weight:10},
  {id:"industry", label:"Industrial capacity", weight:10},
  {id:"readiness", label:"Readiness", weight:5},
  {id:"strategic_depth", label:"Strategic depth", weight:5}
];

const assumptions = [
  "Publicly available information only.",
  "No nuclear weapons or WMD are modeled.",
  "The result is a model estimate, not a prediction.",
  "Political constraints, alliances and geography can materially alter outcomes.",
  "The model compares broad conventional capability; it does not simulate operational plans, targeting or invasion routes."
];

if (dryRun) {
  const packet = {schema_version:"4.0", generated_at:new Date().toISOString(), matchup:{country1:a,country2:b,scenario:"hypothetical conventional conflict",year}, assumptions, categories, sources:[], stats:[], scores:{country1:50,country2:50,method:"deterministic weighted analytical model",category_scores:[]}, verdict:`Model estimate pending research for ${a} vs ${b}.`, narration:`${a} versus ${b}. This is a hypothetical analytical comparison based on public information.`};
  await fs.mkdir("data",{recursive:true});
  await fs.writeFile("data/current-matchup.json", JSON.stringify(packet,null,2));
  console.log(`DRY RUN: prepared research packet for ${a} vs ${b}.`);
  process.exit(0);
}

if (!process.env.GEMINI_API_KEY) throw new Error("GEMINI_API_KEY is required for live research. Add it to .env.");

const model = process.env.GEMINI_MODEL || "gemini-3.1-pro-preview";
const schema = {
  type:"object",
  properties:{
    sources:{type:"array",items:{type:"object",properties:{name:{type:"string"},url:{type:"string"},publisher:{type:"string"},year:{type:"integer"},note:{type:"string"}},required:["name","url","publisher","year","note"]}},
    stats:{type:"array",items:{type:"object",properties:{country:{type:"string"},label:{type:"string"},value:{type:"number"},unit:{type:"string"},year:{type:"integer"},source_name:{type:"string"},source_url:{type:"string"},confidence:{type:"string",enum:["high","moderate","low"]}},required:["country","label","value","unit","year","source_name","source_url","confidence"]}},
    category_scores:{type:"array",items:{type:"object",properties:{id:{type:"string",enum:categories.map(c=>c.id)},country1_score:{type:"number",minimum:0,maximum:100},country2_score:{type:"number",minimum:0,maximum:100},rationale:{type:"string"}},required:["id","country1_score","country2_score","rationale"]}},
    verdict_summary:{type:"string"},
    narration:{type:"string"}
  },
  required:["sources","stats","category_scores","verdict_summary","narration"]
};

const prompt = `You are the research agent for a short-form military comparison video.

Matchup: ${a} vs ${b}
Research year: ${year}
Scenario: hypothetical conventional conflict.

Use Google Search extensively. Prefer primary/authoritative sources where possible: SIPRI, IISS, official defense ministries, NATO/UN data, FlightGlobal or other reputable aviation references, and Global Firepower only as a secondary estimate. Do not invent numbers. If two reputable sources disagree, choose the better-supported figure and explain uncertainty in the source note.

Collect enough public evidence to support all nine categories: air power, ground power, naval power, air defense, logistics, geography, industrial capacity, readiness, strategic depth. Include useful headline stats such as active personnel, aircraft, fighters, tanks, artillery, naval assets/submarines and recent military expenditure when available. Every stat must have a direct source URL and publication/data year.

Then assign each country a 0-100 analytical capability score for EACH category. These are not facts or predictions; they are transparent inputs to a deterministic weighted model. Do not calculate the final weighted score yourself. Keep the rationale concise and evidence-based.

Safety: stay at strategic/analytical level. Do not provide operational attack plans, target lists, invasion routes, tactical instructions, or casualty forecasts.

The final narration should fit roughly 80-90 seconds, sound like a serious intelligence-documentary briefing, and explicitly say the outcome is a model estimate rather than a prediction.`;

const response = await fetch("https://generativelanguage.googleapis.com/v1beta/interactions", {
  method:"POST",
  headers:{"Content-Type":"application/json","x-goog-api-key":process.env.GEMINI_API_KEY},
  body:JSON.stringify({
    model,
    input:prompt,
    tools:[{type:"google_search"}],
    generation_config:{thinking_level:process.env.GEMINI_THINKING_LEVEL || "medium"},
    response_format:{type:"text",mime_type:"application/json",schema}
  })
});

const raw = await response.text();
if (!response.ok) throw new Error(`Gemini API ${response.status}: ${raw.slice(0,1200)}`);
const interaction = JSON.parse(raw);
if (interaction.status && interaction.status !== "completed") throw new Error(`Gemini interaction status: ${interaction.status}`);
const text = interaction.output_text || (interaction.steps||[]).flatMap(s=>s.content||[]).find(x=>x.type==="text")?.text;
if (!text) throw new Error("Gemini returned no structured text output.");
let research;
try { research = JSON.parse(text); } catch { throw new Error(`Gemini output was not valid JSON: ${text.slice(0,800)}`); }

const scoreMap = new Map((research.category_scores||[]).map(x=>[x.id,x]));
for (const c of categories) if (!scoreMap.has(c.id)) throw new Error(`Missing category score: ${c.id}`);

let weightedA=0, weightedB=0;
for (const c of categories) {
  const s=scoreMap.get(c.id);
  weightedA += (Math.max(0,Math.min(100,Number(s.country1_score))) / 100) * c.weight;
  weightedB += (Math.max(0,Math.min(100,Number(s.country2_score))) / 100) * c.weight;
}
const total=weightedA+weightedB || 1;
const scoreA=Number((weightedA/total*100).toFixed(1));
const scoreB=Number((weightedB/total*100).toFixed(1));
const winner = scoreA === scoreB ? "Tie / too close to call" : scoreA > scoreB ? a : b;
const confidence = Math.abs(scoreA-scoreB) >= 15 ? "moderate-high" : Math.abs(scoreA-scoreB) >= 7 ? "moderate" : "low-moderate";

const packet = {
  schema_version:"4.0",
  generated_at:new Date().toISOString(),
  matchup:{country1:a,country2:b,scenario:"hypothetical conventional conflict",year},
  assumptions,
  categories,
  sources:research.sources||[],
  stats:research.stats||[],
  scores:{
    country1:scoreA,
    country2:scoreB,
    winner,
    confidence,
    method:"deterministic weighted analytical model",
    category_scores:categories.map(c=>({id:c.id,label:c.label,weight:c.weight,country1_score:Number(scoreMap.get(c.id).country1_score),country2_score:Number(scoreMap.get(c.id).country2_score),rationale:scoreMap.get(c.id).rationale}))
  },
  verdict:research.verdict_summary || `${winner} has the higher model score, but this is not a prediction.`,
  narration:research.narration || `${a} versus ${b}. This is a hypothetical model estimate based on public information, not a prediction.`
};

await fs.mkdir("data",{recursive:true});
await fs.writeFile("data/current-matchup.json", JSON.stringify(packet,null,2));
await fs.writeFile("data/research-raw.json", JSON.stringify({interaction_id:interaction.id||null,model,usage:interaction.usage||null},null,2));
console.log(`RESEARCH PASS: ${a} vs ${b}`);
console.log(`Model score: ${a} ${scoreA} — ${b} ${scoreB} | ${winner} | confidence=${confidence}`);
console.log(`Sources: ${(research.sources||[]).length}; stats: ${(research.stats||[]).length}; grounded search enabled.`);
