# V9 — 100-Matchup Batch Production

V9 turns the one-click matchup pipeline into a 100-episode production queue.

## Included

- `data/batch-30.json` — 100 curated hypothetical conventional matchups.
- `scripts/batch-30.mjs` — sequential batch runner with manifest output.
- Batch IDs `MM-001` through `MM-100` for stable filenames and tracking.
- Resume-friendly `--start` and `--limit` controls.
- `--dry-run` for checking the queue without API calls.
- `--stop-on-error` for strict production runs.

## Commands

Preview all 100:

```bash
npm run batch30 -- --dry-run
```

Run all 100:

```bash
npm run batch30
```

Run the first 10:

```bash
npm run batch30 -- --limit=10
```

Run episodes 41–60:

```bash
npm run batch30 -- --start=41 --limit=20
```

Stop immediately if an episode fails:

```bash
npm run batch30 -- --stop-on-error
```

## Production behavior

Each matchup goes through the existing one-click pipeline: research → validation → episode specification → narration/captions → render/QC.

The batch runner is intentionally sequential. This reduces the chance of API rate-limit spikes and makes failures easy to resume.

Outputs are organized under:

`output/batch-30/<MM-ID>-<country>-vs-<country>/`

A `manifest.json` records each episode as `planned`, `completed`, or `failed`.

## Editorial safety

Every episode remains a hypothetical analytical comparison. No nuclear/WMD modeling, operational targeting, detailed invasion routes, or tactical attack instructions are generated.

## Data freshness

The research agent should fetch current public sources at generation time. Military expenditure should prefer the current SIPRI Military Expenditure Database where applicable; SIPRI notes that its database is updated annually and can revise historical figures as better sources become available.
