
# V3 One-Click Pipeline

## Commands

Dry run (no paid APIs):
```bash
npm run oneclick -- "Egypt vs Algeria" --dry-run
```

Live:
```bash
npm run oneclick -- "Egypt vs Algeria"
```

The live pipeline is:

**country pair → structured research → QC → ElevenLabs narration → captions → Remotion MP4**

Required environment variables:
- `GEMINI_API_KEY`
- `ELEVENLABS_API_KEY`
- `ELEVENLABS_VOICE_ID`

The research contract requires each important statistic to include:
`label`, `value`, `unit`, `country`, `source`, `source_url`, `year`, `confidence`.

Never publish a matchup whose research packet fails QC.
