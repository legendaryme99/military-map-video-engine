import React from 'react';
import {Audio, staticFile, useCurrentFrame} from 'remotion';
import {loadCaptions} from './captions';

export const Narration=()=> <Audio src={staticFile('audio/narration.mp3')} />;

export const CaptionOverlay=()=>{
  const captions=loadCaptions();
  const frame=useCurrentFrame();
  const t=frame/30*1000;
  const active=captions.find(c=>t>=c.startMs && t<=c.endMs);
  if(!active) return null;
  return <div style={{position:'absolute',left:55,right:55,bottom:105,fontFamily:'Arial',fontWeight:900,fontSize:38,color:'white',textAlign:'center',textShadow:'0 3px 12px #000',lineHeight:1.15}}>{active.text}</div>;
};
