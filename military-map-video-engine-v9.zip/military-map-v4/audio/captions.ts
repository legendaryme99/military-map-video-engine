import fs from 'node:fs';
import type {Caption} from '@remotion/captions';

export function alignmentToCaptions(alignment:any): Caption[] {
  const chars=alignment.characters ?? [];
  const starts=alignment.character_start_times_seconds ?? [];
  const ends=alignment.character_end_times_seconds ?? [];
  const captions: Caption[]=[];
  let text=''; let start=0; let end=0;
  for(let i=0;i<chars.length;i++){
    const ch=chars[i];
    if(!text) start=starts[i]*1000;
    text += ch; end=ends[i]*1000;
    if(/[.!?]\s*$/.test(text) || (text.length>72 && /\s/.test(ch))){
      captions.push({text,startMs:start,endMs:end,timestampMs:(start+end)/2,confidence:null});
      text='';
    }
  }
  if(text) captions.push({text,startMs:start,endMs:end,timestampMs:(start+end)/2,confidence:null});
  return captions;
}
export function loadCaptions(file='public/audio/narration-alignment.json') {
  if(!fs.existsSync(file)) return [] as Caption[];
  return alignmentToCaptions(JSON.parse(fs.readFileSync(file,'utf8')));
}
