# V9 — 90-Second / 30-Matchup Production

V9 replaces the 100-matchup batch with 30 curated matchups and a 90-second vertical episode template.

## Episode structure
- 0–6s: hook/map
- 6–18s: manpower
- 18–30s: air power
- 30–42s: ground power
- 42–52s: naval power
- 52–62s: military spending
- 62–74s: geography, logistics, readiness, industrial capacity
- 74–84s: model verdict
- 84–90s: outro

## Batch commands
`npm run batch30 -- --dry-run`
`npm run batch30 -- --limit=5`
`npm run batch30 -- --start=11 --limit=10`
`npm run batch30 -- --stop-on-error`

Outputs are isolated under `output/batch-30/` and the manifest is updated after each matchup so a long batch can resume safely.

All outcomes are hypothetical model estimates, not predictions. No operational targeting, invasion routes, or tactical instructions are generated.
