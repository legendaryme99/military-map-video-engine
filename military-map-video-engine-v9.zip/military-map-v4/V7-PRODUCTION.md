# V7 Production Visual + QC Layer

V7 adds the production presentation system and a pre-render quality gate.

- 1080x1920, 30fps, 90 seconds.
- Dark intelligence-briefing visual language with restrained gold/blue accents.
- Deterministic MapLibre geography; no AI-generated map geometry.
- Large readable statistics and smooth eased motion.
- No operational attack arrows, target locations, or tactical routes.
- Explicit hypothetical/model-estimate framing.
- Timestamped ElevenLabs narration and high-contrast captions.
- QC blocks rendering when research statistics lack values, source URLs/years, or deterministic scores.
- Remotion composition is named `MilitaryMatchup` and consumes passed matchup props.
