# Military Map Video Engine V7

Automated faceless short-form military comparison engine.

Pipeline: matchup -> grounded research -> deterministic scoring -> episode spec -> audio/captions -> production QC -> Remotion MP4.

```bash
npm install
npm run oneclick -- "Egypt vs Algeria"
```

Dry run:

```bash
npm run oneclick -- "Egypt vs Algeria" --dry-run
```
